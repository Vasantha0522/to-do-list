import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do List',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: TodoListScreen(),
    );
  }
}

class TodoListScreen extends StatefulWidget {
  @override
  _TodoListScreenState createState() => _TodoListScreenState();
}

class _TodoListScreenState extends State<TodoListScreen> {
  final List<Map<String, dynamic>> _todoItems = []; // List to store tasks
  final TextEditingController _textController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  void _addTodoItem(String task, DateTime? date, TimeOfDay? time) {
    if (task.isNotEmpty && date != null && time != null) {
      setState(() {
        _todoItems.add({
          'task': task,
          'date': date,
          'time': time,
        });
      });
      _textController.clear(); // Clear the input field
    }
  }

  void _removeTodoItem(int index) {
    setState(() {
      _todoItems.removeAt(index);
    });
  }

  Widget _buildTodoItem(Map<String, dynamic> todo, int index) {
    return ListTile(
      title: Text(todo['task']),
      subtitle: Text(
        'Due: ${todo['date'].toLocal().toString().split(' ')[0]} at ${todo['time'].format(context)}',
      ),
      trailing: IconButton(
        icon: Icon(Icons.delete, color: Colors.red),
        onPressed: () => _removeTodoItem(index),
      ),
    );
  }

  Future<void> _showAddTodoDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Add a new task'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _textController,
                decoration: InputDecoration(hintText: 'Enter task here'),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Text('Date: '),
                  TextButton(
                    onPressed: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2101),
                      );
                      setState(() {
                        _selectedDate = pickedDate;
                      });
                    },
                    child: Text(
                      _selectedDate == null
                          ? 'Select Date'
                          : _selectedDate!.toLocal().toString().split(' ')[0],
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Text('Time: '),
                  TextButton(
                    onPressed: () async {
                      TimeOfDay? pickedTime = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.now(),
                      );
                      setState(() {
                        _selectedTime = pickedTime;
                      });
                    },
                    child: Text(
                      _selectedTime == null
                          ? 'Select Time'
                          : _selectedTime!.format(context),
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _textController.clear(); // Clear input if canceled
              },
            ),
            TextButton(
              child: Text('Add'),
              onPressed: () {
                Navigator.of(context).pop();
                _addTodoItem(
                    _textController.text, _selectedDate, _selectedTime);
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('To-Do List'),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/bg.webp'), // Background image
            fit: BoxFit.cover,
          ),
        ),
        child: ListView.builder(
          itemCount: _todoItems.length,
          itemBuilder: (context, index) {
            return _buildTodoItem(_todoItems[index], index);
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTodoDialog,
        tooltip: 'Add Task',
        child: Icon(Icons.add),
      ),
    );
  }
}
